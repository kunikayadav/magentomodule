<?php
class Newsletter_News_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup {
}