<?php
class Newsletter_News_Adminhtml_News_IndexController extends Mage_Adminhtml_Controller_Action
{
    /**
     * Init actions
     *
     */
    protected function _initAction()
    {
        $this->loadLayout()
            ->_setActiveMenu('templates/news_index/index')
            ->_addBreadcrumb(
                Mage::helper('news')->__('News'),
                Mage::helper('news')->__('Manage Test')
            );
        return $this;
    }

    public function indexAction()
    {
        $this->_title($this->__('Templates'))
            ->_title($this->__('News'))
            ->_title($this->__('Manage Test'));

        $this->_initAction();
        $this->renderLayout();
    }

    public function newAction()
    {
        // the same form is used to create and edit
        $this->_forward('edit');
    }
}
?>