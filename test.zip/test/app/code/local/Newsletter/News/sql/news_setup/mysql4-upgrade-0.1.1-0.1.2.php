<?php

$installer = $this;
$connection = $installer->getConnection();

$installer->startSetup();

$installer->getConnection()
    ->changeColumn($installer->getTable('news/newspost'),'last_upadated_at','last_upadated_at_this',array('type' => Varien_Db_Ddl_Table::TYPE_TIMESTAMP,'nullable' => true,'default' => null,'comment' => 'Last Updated At')
    );

$installer->endSetup();

?>