<?php
class Newsletter_News_Model_Newspost extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('news/newspost');
    }

}